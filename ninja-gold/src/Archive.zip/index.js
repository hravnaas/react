import React from 'react';
import ReactDOM from 'react-dom';
// import App from './App';
import NinjaGoldApp from './ninja_gold';
import './index.css';

ReactDOM.render(
  <NinjaGoldApp />,
  document.getElementById('root')
);
